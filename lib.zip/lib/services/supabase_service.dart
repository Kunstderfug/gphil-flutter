class SupabaseService {
  static const String _supabaseUrl =
      'https://gprktgiajxiwjzjsqdly.supabase.co/storage/v1/object/public/';

  String get supabaseUrl => _supabaseUrl;
}
