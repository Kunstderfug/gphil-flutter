import 'package:flutter/material.dart';

import 'package:gphil/components/performance/main_area.dart';

class LaptopBody extends StatelessWidget {
  const LaptopBody({super.key});

  @override
  Widget build(BuildContext context) {
    return MainArea();
  }
}
